﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ApplicationParaTest;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
       
       


        /// <summary>
        /// Metodo: darVuelta();
        /// Alcance: Queremos comprobar que el metodo darVuelta funciona correctamente, es decir de la vuelta a la cadena de texto
        /// Entrada: cadena asdf
        /// Salida: cadena esperada fdsa
        /// </summary>
        [TestMethod]
        public void darVueltaTest()
        {
            Console.WriteLine("Ejecutando darVueltaTest \n");
            string cadena_original = "asdf";
            string cadena_esperada = "fdsa";
            Console.WriteLine("Cadena original: " + cadena_original + "\n");
            Console.WriteLine("Cadena esperada: " + cadena_esperada + "\n");
            string cadena_recibida = EjercicioCaracteres.darVuelta(cadena_original);
            Assert.AreEqual(cadena_esperada, cadena_recibida);
            Console.WriteLine("Cadena real: " + cadena_recibida + "\n");
            Console.WriteLine("FIN DEL TEST - darVuelta()");
        }

        /// <summary>
        /// Metodo: sacarAsento();
        /// Alcance: Queremos comprobar que el metodo sacarAsento funciona correctamente, es decir quite los acentos de las letras
        /// Entrada: cadena áéíóú
        /// Salida: cadena esperada áéíóú
        /// </summary>
        [TestMethod]
        public void sacarAsentoTest()
        {
            Console.WriteLine("Ejecutando sacarAsentoTest() \n");
            string cadena_original = "áéíóúâê";
            string cadena_esperada = "aeiouae";
            Console.WriteLine("Cadena original: " + cadena_original + "\n");
            Console.WriteLine("Cadena esperada: " + cadena_esperada + "\n");
            string cadena_recibida = EjercicioCaracteres.sacarAcentos(cadena_original);
            Assert.AreEqual(cadena_esperada, cadena_recibida);
            Console.WriteLine("Cadena real: " + cadena_recibida + "\n");
            Console.WriteLine("FIN DEL TEST - sacarAsento()");
        }

        /// <summary>
        /// Metodo: transformarTextoTest();
        /// Alcance: Queremos comprobar que el metodo transformarTesto() funciona correctamente, es decir quite los espacios,
        /// ponga todo en minuscula excepto vocalesde las letras
        /// Entrada: cadena áéíóú
        /// Salida: cadena esperada áéíóú
        /// </summary>
        [TestMethod]
        public void transformarTextoTest()
        {
            Console.WriteLine("Ejecutando transformarTextoTest() \n");
            string cadena_original = "hola qué tal";
            string cadena_esperada = "lAtEUqAlOh";
            Console.WriteLine("Cadena original: " + cadena_original + "\n");
            Console.WriteLine("Cadena esperada: " + cadena_esperada + "\n");
            string cadena_recibida = EjercicioCaracteres.transformaTexto(cadena_original);
            Assert.AreEqual(cadena_esperada, cadena_recibida);
            Console.WriteLine("Cadena real: " + cadena_recibida + "\n");
            Console.WriteLine("FIN DEL TEST - sacarAsento()");
        }

        /// <summary>
        ///  Metodo: leerArchivoTest();
        /// Alcance: obtener el texto de un fichero
        /// Entrada: ningun elemento
        /// Salida: texto recibido
        /// Este metodo no recibe nada y es static por lo que solo puede darnos dos resultados posibles o el fichero seleccionado existe y nos muestra
        /// su contenido o bien el fichero no existe y devuelve una cadena de texto vacio.
        /// Como el fichero se menciona en el metodo y no se le pasa el valor por parametro el resultado sera siempre el mismo
        /// </summary>
        /// <returns></returns>
        public static String leerArchivoTest()
        {
            
            return EjercicioCaracteres.leerArchivo();
        }


    }
}
